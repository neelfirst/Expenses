﻿namespace Expenses
{
}
namespace Expenses {
    
    
    public partial class LineItems {
    }
}
